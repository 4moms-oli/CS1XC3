/**
 * @file student.h
 * @author Oliver Metz-Strauss
 * @date 2022-04-11
 * @brief Student library for managing students, inclduding student type definition
 *        and student functions.
 * 
 */


/**
 * @brief Student type stores a student with fields first_name, last_name, id, grades, and num_grades.
 * 
 */
typedef struct _student 
{ 
  char first_name[50]; /**< the student's first name */
  char last_name[50]; /**< the student's last name */
  char id[11]; /**< the student's student ID */
  double *grades; /**< the student's grades */
  int num_grades; /**< the number of grades a student has */
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
