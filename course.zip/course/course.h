/**
 * @file course.h
 * @author Oliver Metz-Strauss
 * @brief Course library for managing courses, inclduding course type definition
 *        and course functions.
 * @date 2022-04-11
 */

#include "student.h"
#include <stdbool.h>
 
/**
 * @brief Course type stores a course with fields name, code, students, total_students.
 * 
 */
typedef struct _course 
{
  char name[100]; /**< the course name */
  char code[10]; /**< the course code */
  Student *students; /** an array of students enrolled in the course */
  int total_students; /** the total number of students enrolled in the course */
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


